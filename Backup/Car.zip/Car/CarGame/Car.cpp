#include "Car.h"
#include <ctime>
#include <chrono>
#include <thread>
#include <math.h>

using namespace std;

Car::Car(const std::string &name):_carName(name)
{

}

Car::~Car()
{

}

void Car::SetEngine(std::unique_ptr<Engine> &engine)
{
    this->_engine = std::move(engine);
}

void Car::Simulate()
{
   clock_t start = clock(), elapsed;
   float gas;

   while(elapsed<=10)
   {
       _engine->Gas(std::sqrt(++gas));

      elapsed = (clock()-start)/CLOCKS_PER_SEC;
      std::this_thread::sleep_for(std::chrono::milliseconds(5));
   }

}
